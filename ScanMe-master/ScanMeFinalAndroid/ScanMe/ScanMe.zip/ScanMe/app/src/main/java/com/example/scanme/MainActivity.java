package com.example.scanme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;

public class MainActivity extends AppCompatActivity implements BarCode.OnFragmentInteractionListener,ScanBarcode.OnFragmentInteractionListener
,Share.OnFragmentInteractionListener,ScanAndShare.OnFragmentInteractionListener,ScanAndShareBarcodeScan.OnFragmentInteractionListener{
    SharedPreferences sharedpreferences;
   String name,email,phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
         name=preferences.getString("name","");
        email=preferences.getString("email","");
        phone=preferences.getString("phone","");
        if(phone.length()==0){
            Intent intent=new Intent(getApplicationContext(),DetainsEntry.class);
            startActivity(intent);
        }else{

        getSupportFragmentManager().beginTransaction().addToBackStack("list")
                .replace(R.id.container, new BarCode(name,email,phone))
                .commit();
        }


    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
