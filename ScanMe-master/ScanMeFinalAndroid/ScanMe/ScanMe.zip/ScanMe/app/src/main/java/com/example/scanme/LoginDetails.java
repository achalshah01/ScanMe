package com.example.scanme;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;


public class LoginDetails extends Fragment {
 CallbackManager callbackManager;
 Button loginButton,save;
 EditText phone,name,email;
    private static final String EMAIL = "email";

    private OnFragmentInteractionListener mListener;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        callbackManager = CallbackManager.Factory.create();
        View view = inflater.inflate(R.layout.fragment_login_details, container, false);
        name =  view.findViewById(R.id.name);
        email =  view.findViewById(R.id.email);
        phone =  view.findViewById(R.id.phone);
        save = view.findViewById(R.id.save);
       /// loginButton = (LoginButton) view.findViewById(R.id.login_button);




        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText().toString().length()==0){
                    name.setError("This field can not be blank");
                }else  if(phone.getText().toString().length()==0){
                    phone.setError("This field can not be blank");
                }else{
                    String e=null;
                    if(email.getText().toString().length()==0){e="null";}
                    else{e=email.getText().toString();}
                  mListener.  sendEmail(name.getText().toString(),phone.getText().toString(),e);
                }
            }
        });


        return view;
    }


    // TODO: Rename method, update argument and hook method into UI event


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
         void sendEmail(String name, String phone, String e);
    }
}
